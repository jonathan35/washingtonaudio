fewlines
========
http://sergeir82.github.io/fewlines/
About:
--------

Fewlines - is a lightweight jQuery plug-in to cut the text to a specified number of rows. The plugin was written in CoffeeScript, and easy to use:

$('#sample').fewlines();

Plugin options:
--------

**lines** - The number of lines that you want to show. If amount of text less than a specified number of lines, the text will remain as is (default 2).

**openMark** - Open mark label (default '...').

**newLine** - If this option is true the open mark is placed on new line (default false).

**closeMark** - Close mark label (default 'close').
